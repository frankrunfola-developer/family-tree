// static/js/treeConfig.js
// ----------------------------------------------------------------------------
// Tree rendering + layout knobs (single source of truth).
// Imported by both `tree.js` and `familyTree.js`.
//
// If you want to change how the tree *looks* without touching layout/render code,
// change values in this file first.
// ----------------------------------------------------------------------------

export const TREE_CFG = {
  // Dagre layout (graph -> x/y positions)
  dagre: {
    rankdir: "TB",  // Extra padding around the dagre graph
    ranksep: 65, // Vertical distance between generations (rows)
    nodesep: 100,// Horizontal distance between nodes (columns)
    marginx: 10,   // Extra padding around the dagre graph
    marginy: 10,
  },

  // Node/card sizing (all dimensions in SVG px)
  sizing: {
    CARD_W: 310,     // person card width
    CARD_H: 250,     // person card height
    CARD_R: 16,      // card corner radius
    PHOTO_R: 80,   // single source of truth for circle size
    PHOTO_Y: 14,   // top offset of the circle’s bounding box
},

  // Card text baseline positions (relative to card top-left)
  text: {
    NAME_Y: 190,
    META_Y: 220
  },

  // Text styling (SVG text)
  fonts: {
    NAME_PX: 31,   // name font size
    META_PX: 27,   // date/meta font size
    WEIGHT_NAME: 600,
    WEIGHT_META: 500,
  },


  // Link routing knobs (elbows + stems)
  links: {
    // ONE knob for ALL vertical stems (the "drop" length used to build elbows):
    // - parent drops down to the couple join line
    // - trunk from the couple join line down to the union point
    // - union-to-child elbow vertical stem (from union point to the elbow)
    STEM: 30,   // If your connectors look too "tall" or too "flat", change *only* this value.
  },

  // Spacing policy (mostly used when building the graph)
  spacing: {
    SPOUSE_GAP: 20,
    SIBLING_GAP: 80,
    CLUSTER_GAP: 62,
    COUPLE_KEEP_OUT_PAD: 12,
    ROW_EPS: 10,
  },

  // ViewBox framing / padding for the SVG viewport
  view: {
    minWidth: 1050,
    minHeight: 620,
    pad: 18,
    extra: 54,
  },
};